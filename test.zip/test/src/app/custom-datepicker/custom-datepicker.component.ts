import { Component, EventEmitter, Input, OnChanges, ChangeDetectorRef, OnInit, Output, AfterViewChecked, SimpleChanges } from '@angular/core';
import * as moment from 'moment';
import * as _ from 'lodash';
declare let $: any;

export interface CalendarDate {
  mDate: moment.Moment;
  selected?: boolean;
  today?: boolean;
}

@Component({
  selector: 'app-custom-calendar',
  templateUrl: './custom-datepicker.component.html',
  styleUrls: ['./custom-datepicker.component.scss']
})
export class CalendarComponent implements OnInit, OnChanges, AfterViewChecked  {
  setHours:any = ['8 AM','9 AM','10 AM','11 AM','12 PM','1 PM','3 PM','4 PM','5 PM','6 PM','7 PM','8PM'];
  currentDate = moment();
  boxToggle:boolean;
  userData:any;
  customselectedDate:any='';
  dayNames = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  weeks: CalendarDate[][] = [];
  sortedDates: CalendarDate[] = [];

  @Input() selectedDates: CalendarDate[] = [];
  @Output() onSelectDate = new EventEmitter<CalendarDate>();

  constructor(private cdRef : ChangeDetectorRef) {
    this.boxToggle=false;
    this.userData = {'menuitem': [
        {'name': 'Raju', 'slots': [
        {'date':'May 1, 2018 01:15:00'},
        {'date':'May 3, 2018 01:15:00'},
        {'date':'May 4, 2018 01:15:00'},
        {'date':'May 5, 2018 01:15:00'}
        ]
        },
        {'name': 'raghu', 'slots': [
        {'date':1525113000000},
        {'date':1525199400000},
        {'date':1525285800000},
        {'date':1525372200000}
        ]
        },{'name': 'ramesh', 'slots': [
        {'date':1525113000000},
        {'date':1525199400000},
        {'date':1525285800000},
        {'date':1525372200000}
        ]
        }
      ]      
    }
  }

  ngOnInit(): void {
    this.generateCalendar();
    setTimeout(function(){
     this.boxToggle = false; 
    })
  //  $("#boxplay").hide();
  }
  ngAfterViewChecked() {
    // let boxToggle = this.isShowExpand(0);
    // if (boxToggle != this.boxToggle) { // check if it change, tell CD update view
    //   this.boxToggle = boxToggle;
    //   this.cdRef.detectChanges();
    // }
  }
  isShowExpand(a){
    if(a===0){
      return false;
    }else{
      return true;
    }
  }
  isTimeBlocked(date) {
    console.log(date);
    this.selectedDate=date;
//    this.boxToggle=true;
   // $("#boxplay").show();
   // this.isShowExpand(1);
      for(var i=0;i<this.userData.menuitem[0].slots.length;i++){
          var da = new Date(this.userData.menuitem[0].slots[i].date).getDate()
          var d = new Date(date.mDate._d.getFullYear(), date.mDate._d.getMonth()-1, date.mDate._d.getDate());
          if(d.getDate() === da && (da!==undefined || d !=undefined)){
            return true;
          }
      }  
    
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.boxToggle=false;
    if (changes.selectedDates &&
        changes.selectedDates.currentValue &&
        changes.selectedDates.currentValue.length  > 1) {
      // sort on date changes for better performance when range checking
      this.sortedDates = _.sortBy(changes.selectedDates.currentValue, (m: CalendarDate) => m.mDate.valueOf());
      this.generateCalendar();
    }
  }

  // date checkers
  isToday(date: moment.Moment): boolean {
    return moment().isSame(moment(date), 'day');
  }

  isSelected(date: moment.Moment): boolean {
    return _.findIndex(this.selectedDates, (selectedDate) => {
      return moment(date).isSame(selectedDate.mDate, 'day');
    }) > -1;
  }

  isSelectedMonth(date: moment.Moment): boolean {
    return moment(date).isSame(this.currentDate, 'month');
  }

  selectDate(date: CalendarDate): void {
    this.onSelectDate.emit(date);
    this.customselectedDate=date;
    this.boxToggle=true;
  }
  closebox(){
    this.boxToggle=false;
  }

  // actions from calendar
  prevMonth(): void {
    this.currentDate = moment(this.currentDate).subtract(1, 'months');
    this.generateCalendar();
  }

  nextMonth(): void {
    this.currentDate = moment(this.currentDate).add(1, 'months');
    this.generateCalendar();
  }

  firstMonth(): void {
    this.currentDate = moment(this.currentDate).startOf('year');
    this.generateCalendar();
  }

  lastMonth(): void {
    this.currentDate = moment(this.currentDate).endOf('year');
    this.generateCalendar();
  }

  prevYear(): void {
    this.currentDate = moment(this.currentDate).subtract(1, 'year');
    this.generateCalendar();
  }

  nextYear(): void {
    this.currentDate = moment(this.currentDate).add(1, 'year');
    this.generateCalendar();
  }

  // generate the calendar grid
  generateCalendar(): void {
    const dates = this.fillDates(this.currentDate);
    const weeks: CalendarDate[][] = [];
    while (dates.length > 0) {
      weeks.push(dates.splice(0, 7));
    }
    this.weeks = weeks;
  }

  fillDates(currentMoment: moment.Moment): CalendarDate[] {
    const firstOfMonth = moment(currentMoment).startOf('month').day();
    const firstDayOfGrid = moment(currentMoment).startOf('month').subtract(firstOfMonth, 'days');
    const start = firstDayOfGrid.date();
    return _.range(start, start + 42)
            .map((date: number): CalendarDate => {
              const d = moment(firstDayOfGrid).date(date);
              return {
                today: this.isToday(d),
                selected: this.isSelected(d),
                mDate: d,
              };
            });
  }
}