import { Directive,HostListener,AfterViewInit } from '@angular/core';
declare let $: any;
@Directive({
  selector: '[appStopPropagation]'
})
export class StopPropagationDirective implements AfterViewInit {

  @HostListener("click", ["$event"]);
  constructor(){
    console.log("Testing");
  }
  public onClick(event: any): void
  {
      event.stopPropagation();
      event.preventDefault();
  }
  ngAfterViewInit() {
    $(document).on("click","#boxplay button",function(event){
      //alert("Testing");
//      console.log(event);
      event.stopPropagation();
      event.preventDefault();
    })
  }

}
