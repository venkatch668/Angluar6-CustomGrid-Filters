import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customcalendar',
  templateUrl: './customcalendar.component.html',
  styleUrls: ['./customcalendar.component.css']
})
export class CustomcalendarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
