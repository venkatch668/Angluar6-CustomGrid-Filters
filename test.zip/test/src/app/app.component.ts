import { Component, OnInit, AfterViewInit, Output, EventEmitter } from '@angular/core';
import {NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { StopPropagationDirective } from './stop-propagation.directive';
declare let $: any;
const now = new Date();

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, AfterViewInit {
  model : NgbDateStruct;
  model2 : NgbDateStruct;
  model3 : NgbDateStruct;
  date: {year: number, month: number};
  taskDate:any=[];
  newdate=3;
  boxToggle:any;
  closeResult: string;
  selectedDate:any;
  userData:any;
  loadState:boolean=true;
  setHours:any = [8,9,10,11,12,1,3,4,5,6,7,8];

  @Output() dateSelect = new EventEmitter<NgbDateStruct>();
  
  constructor(private modalService: NgbModal){
    for(var i=0;i<3;i++){
      this.setDate();
    }  
    this.userData = {'menuitem': [
        {'name': 'Raju', 'slots': [
        {'date':'May 1, 2018 01:15:00'},
        {'date':'May 3, 2018 01:15:00'},
        {'date':'May 4, 2018 01:15:00'},
        {'date':'May 5, 2018 01:15:00'}
        ]
        },
        {'name': 'raghu', 'slots': [
        {'date':1525113000000},
        {'date':1525199400000},
        {'date':1525285800000},
        {'date':1525372200000}
        ]
        },{'name': 'ramesh', 'slots': [
        {'date':1525113000000},
        {'date':1525199400000},
        {'date':1525285800000},
        {'date':1525372200000}
        ]
        }
      ]      
    }
  }
 
  
  ngOnInit(){
  }
  
    ngAfterViewInit() {      
    setTimeout(function(){
      $('.input-group-addon').click();
      this.loadState=false;
    },1000);
   
  }
  clickemitter(event){
    console.log(event);
  }
  onDateSelect(d){
      this.boxToggle=true;
      this.selectedDate=d;
      setTimeout(function(){
        $('.input-group-addon').click();
      },100);
  }
  
  setDate(){
    let date = new Date();    
    let f= new Date().getFullYear();
    let m= new Date().getMonth();
    let d=new Date().getDay()+this.newdate;
    date.setFullYear(f,m,d);
    this.newdate++;
    this.taskDate.push(date);

  }
 
  
  
    isTimeBlocked(date: NgbDateStruct) {
      if(this.loadState){
        for(var i=0;i<this.userData.menuitem[0].slots.length;i++){
            var da = new Date(this.userData.menuitem[0].slots[i].date).getDate()
            var d = new Date(date.year, date.month - 1, date.day);
            if(d.getDate() === da && (da!==undefined || d !=undefined)){
              return true;
            }
        }  
      }
    }
  
     isDisabled(date: NgbDateStruct, current: {month: number}) {
      
     }
}
