import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { FormsModule} from '@angular/Forms'
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { StopPropagationDirective } from './stop-propagation.directive';
import { CalendarComponent } from './custom-datepicker/custom-datepicker.component';
import { CustomcalendarComponent } from './customcalendar/customcalendar.component';


@NgModule({
  declarations: [
    AppComponent,
    StopPropagationDirective,
    CalendarComponent,
    CustomcalendarComponent
  ],
  imports: [
    BrowserModule,NgbModule.forRoot(),FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
