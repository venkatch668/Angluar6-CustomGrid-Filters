import { StopPropagationDirective } from './stop-propagation.directive';

describe('StopPropagationDirective', () => {
  it('should create an instance', () => {
    const directive = new StopPropagationDirective();
    expect(directive).toBeTruthy();
  });
});
